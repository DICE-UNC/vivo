package databook.listener;

import java.io.InputStream;

public interface RDFDatabase {
	public enum Format { N3, RDF_XML }
	public interface RDFDatabaseTransaction {
		
		public void start() throws RDFDatabaseException;
		public void commit() throws RDFDatabaseException;
		public void abort();
		public void add(String rdf, Format format, String model);
		public void remove(String rdf, Format format, String model);

	}
	
	public class RDFDatabaseException extends Exception {

		public RDFDatabaseException(Exception e) {
			super(e);
			
		}
		
	}

	RDFDatabaseTransaction newTransaction();
	String getValue(String subject, String property);
	InputStream describe(String subject, Format format) throws RDFDatabaseException;
}
