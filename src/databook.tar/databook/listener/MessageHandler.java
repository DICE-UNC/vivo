package databook.listener;

public interface MessageHandler {

	void handle(String message);

}
