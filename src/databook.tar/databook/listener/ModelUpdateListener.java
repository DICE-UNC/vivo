package databook.listener;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.rabbitmq.client.ConsumerCancelledException;
import com.rabbitmq.client.ShutdownSignalException;

import edu.cornell.mannlib.vitro.webapp.beans.Individual;
import edu.cornell.mannlib.vitro.webapp.beans.ObjectPropertyStatementImpl;
import edu.cornell.mannlib.vitro.webapp.dao.IndividualDao;
import edu.cornell.mannlib.vitro.webapp.dao.ObjectPropertyStatementDao;
import edu.cornell.mannlib.vitro.webapp.dao.VitroVocabulary;
import edu.cornell.mannlib.vitro.webapp.dao.WebappDaoFactory;
import edu.cornell.mannlib.vitro.webapp.filestorage.UploadedFileHelper;
import edu.cornell.mannlib.vitro.webapp.filestorage.backend.FileStorage;
import edu.cornell.mannlib.vitro.webapp.filestorage.backend.FileStorageSetup;
import edu.cornell.mannlib.vitro.webapp.filestorage.model.FileInfo;
import edu.cornell.mannlib.vitro.webapp.rdfservice.RDFService;
import edu.cornell.mannlib.vitro.webapp.rdfservice.RDFServiceFactory;
import edu.cornell.mannlib.vitro.webapp.rdfservice.impl.RDFServiceUtils;

public class ModelUpdateListener implements ServletContextListener {

	private ExecutorService execService;
	static final Log log = LogFactory.getLog(ModelUpdateListener.class);
	private static final String AMQP_HOST = "localhost";
	private static final String AMQP_QUEUE = "metaQueue";
	private RDFServiceFactory rdfServiceFactory;
	private RDFService rdfService;
	public RDFDatabase database;
	private FileStorage fileStorage;
	private ServletContext servletContext;
	private WebappDaoFactory webAppDaoFactory;
	private UploadedFileHelper uploadedFileHelper;
	public static ModelUpdateListener instance = null;
	public static ModelUpdater modelUpdater;

	@Override
	public void contextInitialized(final ServletContextEvent sce) {
		// initialize context vars
		servletContext = sce.getServletContext();
		Object o = servletContext.getAttribute(FileStorageSetup.ATTRIBUTE_NAME);
		fileStorage = (FileStorage) o;
		webAppDaoFactory = (WebappDaoFactory) servletContext.getAttribute("webappDaoFactory");
		uploadedFileHelper = new UploadedFileHelper(fileStorage, webAppDaoFactory, servletContext);
		
		execService = Executors.newSingleThreadExecutor();
		execService.submit(new Runnable() {
			@Override
			public void run() {
				try {
					log.info("Databook plugin started");
					rdfServiceFactory = RDFServiceUtils
							.getRDFServiceFactory(sce.getServletContext());
					rdfService = rdfServiceFactory.getRDFService();
					database = new VIVORDFDatabase(rdfService, webAppDaoFactory);
					modelUpdater = new ModelUpdater(database);

					AMQPClient.receiveMessage(AMQP_HOST, AMQP_QUEUE,
							modelUpdater);

				} catch (IOException e) {
					log.error(e.getLocalizedMessage());
				} catch (ShutdownSignalException e) {
					log.error(e.getLocalizedMessage());
				} catch (ConsumerCancelledException e) {
					log.error(e.getLocalizedMessage());
				} catch (InterruptedException e) {
					log.error(e.getLocalizedMessage());
				}

			}
		});
		instance = this;
	}
	

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
	}

	public static void logFully(InputStream ris) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(ris));
		String line;
		try {
			while ((line = reader.readLine()) != null) {
				log.info(line);
			}
		} catch (IOException e1) {
			log.error(e1.getLocalizedMessage());
		} finally {
			try {
				reader.close();
			} catch (IOException e1) {
				log.error(e1.getLocalizedMessage());
			}
		}
	}
	
	public void updateImage(String entityUri, String thumbImageObjPath, String mainImageObjPath) throws IOException {
		log.info("Try to set images on '" + entityUri + "': objPath=" + thumbImageObjPath + ", " + mainImageObjPath);

		FileNames fileNames = getFileNames();
		
		// all thumbnails/previews have the "image/jpeg" MIME type
		Process p = Runtime.getRuntime().exec("iget "+mainImageObjPath+" "+fileNames.nameTmp);
		waitAndLog(log, p);

		FileInputStream fis = new FileInputStream(fileNames.nameTmp);
		FileInfo mainInfo = uploadedFileHelper.createFile(fileNames.name, "image/jpeg", fis);
		
		p = Runtime.getRuntime().exec("iget "+thumbImageObjPath+" "+fileNames.thumbNameTmp);
		waitAndLog(log, p);

		FileInputStream fisThumb = new FileInputStream(fileNames.thumbNameTmp);
		FileInfo thumbInfo = uploadedFileHelper.createFile(fileNames.thumbName, "image/jpeg", fisThumb);
		
		IndividualDao individualDao = webAppDaoFactory.getIndividualDao();
		// DataPropertyStatementDao dataPropertyStatementDao = webAppDaoFactory.getDataPropertyStatementDao();
		ObjectPropertyStatementDao objectPropertyStatementDao = webAppDaoFactory.getObjectPropertyStatementDao();

		Individual entity = individualDao.getIndividualByURI(entityUri);
		if (entity == null) {
			throw new NullPointerException("No entity found for URI '"
					+ entityUri + "'.");
		}

		// Add the thumbnail file to the main image file.
		objectPropertyStatementDao
				.insertNewObjectPropertyStatement(new ObjectPropertyStatementImpl(
						mainInfo.getUri(), VitroVocabulary.FS_THUMBNAIL_IMAGE,
						thumbInfo.getUri()));

		// Add the main image file to the entity.
		entity.setMainImageUri(mainInfo.getUri());
		individualDao.updateIndividual(entity);

		log.info("Set images on '" + entity.getURI() + "': main=" + mainInfo
				+ ", thumb=" + thumbInfo);

		Process p2 = Runtime.getRuntime().exec("rm "+fileNames.nameTmp);
		waitAndLog(log, p2);
	}
	
	public static class FileNames {
		public String nameTmp;
		public String name;
		public String thumbName;
		public String thumbNameTmp;
		public FileNames(String tmpName, String thumbName, String name, String id) {
			this.nameTmp = tmpName;
			this.thumbName = thumbName;
			this.name = name;
			this.thumbNameTmp = id;
		}
	}
	
	// util methods
	private static long lastAccessTime;
	private static int lastAccessTimeCount;
	public static synchronized FileNames getFileNames() {
		long currTime = System.currentTimeMillis();
		if(currTime > lastAccessTime) {
			lastAccessTime = currTime;
			lastAccessTimeCount = 1;
		} else {
			lastAccessTimeCount++;
		}
		String idBase = lastAccessTime + "_" + (lastAccessTimeCount - 1);
		return new FileNames("/tmp/databook.tmp" + idBase, "databook.thumb"+idBase, "databook."+idBase, "databook_"+idBase);
		
	}
	
	public static void waitAndLog(Log log, Process p) {
	try{
		BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));

		    BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));

			String s;
		    // read the output from the command
		    System.out.println("Here is the standard output of the command:\n");
		    while ((s = stdInput.readLine()) != null) {
		        log.info(s);
		    }
		    
		    // read any errors from the attempted command
		    System.out.println("Here is the standard error of the command (if any):\n");
		    while ((s = stdError.readLine()) != null) {
		        log.error(s);
		    }
		    p.waitFor();

	} catch(IOException e) {
		throw new Error(e);
	}	catch(InterruptedException e) {
		throw new Error(e);
			}
	}

}
