package databook.listener;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import edu.cornell.mannlib.vitro.webapp.beans.Individual;
import edu.cornell.mannlib.vitro.webapp.dao.IndividualDao;
import edu.cornell.mannlib.vitro.webapp.dao.WebappDaoFactory;
import edu.cornell.mannlib.vitro.webapp.rdfservice.ChangeSet;
import edu.cornell.mannlib.vitro.webapp.rdfservice.RDFService;
import edu.cornell.mannlib.vitro.webapp.rdfservice.RDFService.ModelSerializationFormat;
import edu.cornell.mannlib.vitro.webapp.rdfservice.RDFServiceException;

public class VIVORDFDatabase implements RDFDatabase {
	public RDFService rdfService;
	private WebappDaoFactory webAppDaoFactory;


	public VIVORDFDatabase(RDFService rdfService,
			WebappDaoFactory webAppDaoFactory) {

		this.rdfService = rdfService;
		this.webAppDaoFactory = webAppDaoFactory;
	}

	private static final Log log = LogFactory.getLog(ModelUpdateListener.class);

	public class VIVORDFDatabaseTransaction implements RDFDatabaseTransaction {

		ChangeSet cs;
		List<InputStream> iss = new ArrayList<InputStream>();

		public void start() throws RDFDatabaseException {
			try {
				cs = rdfService.manufactureChangeSet();
			} catch (Exception e) {
				throw new RDFDatabaseException(e);
			}
		}

		public void commit() throws RDFDatabaseException {
			try {
				rdfService.changeSetUpdate(cs);
			} catch (RDFServiceException e) {
				throw new RDFDatabaseException(e);
			} finally {
				for (InputStream is : iss) {
					closeIfNotNull(is); // not necessary
				}
				iss.clear();
			}

		}

		public void abort() {
			for (InputStream is : iss) {
				closeIfNotNull(is); // not necessary
			}
			iss.clear();

		}

		public void add(String n3StrAdd, Format format, String model) {
			log.info("add rdf '" + n3StrAdd + "'");
			InputStream isAdd = new ByteArrayInputStream(n3StrAdd.getBytes());
			cs.addAddition(isAdd, translate(format), model);
		}

		public void remove(String n3StrRem, Format format, String model) {
			InputStream isRem = new ByteArrayInputStream(n3StrRem.getBytes());
			cs.addRemoval(isRem, translate(format), model);
		}

		
		private void closeIfNotNull(InputStream... iss) {
			for (InputStream is : iss) {
				if (is != null) {
					try {
						is.close();
					} catch (IOException e) {
						log.error(e.getLocalizedMessage());
					}
				}
			}
		}

	}

	@Override
	public RDFDatabaseTransaction newTransaction() {
		return new VIVORDFDatabaseTransaction();
	}

	@Override
	public String getValue(String subject, String property) {
		// get old value
		IndividualDao individualDao = webAppDaoFactory.getIndividualDao();

		Individual entity = individualDao.getIndividualByURI(subject);
		if (entity == null) {
			throw new NullPointerException("No entity found for URI '"
					+ subject + "'.");
		}
		String valueOld = entity.getDataValue(property);
		return valueOld;
	}

	@Override
	public InputStream describe(String subject, Format format) throws RDFDatabaseException {
		try {
			return rdfService.sparqlDescribeQuery(subject, translate(format));
		} catch (RDFServiceException e) {
			throw new RDFDatabaseException(e);
		}
	}
	
	private ModelSerializationFormat translate(Format f) {
		switch (f) {
		case N3:
			return ModelSerializationFormat.N3;
		case RDF_XML:
			return ModelSerializationFormat.RDFXML;
		default:
			return null;
		}
	}
	
}
